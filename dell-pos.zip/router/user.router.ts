import express from 'express';
import requestValidator from '../middleware/request.validator';

const userRouter = express.Router();



export default userRouter;