import express from 'express';
import controller from '../controller/policy.controller';
import permission from '../middleware/permission';
import tokenValidator from '../middleware/token.validator';

const router = express.Router();

router.use(tokenValidator.tokenValidate());

router.post('/',  controller.create); 
router.put('/', controller.update);
router.delete('/', controller.remove); 
router.get('/', controller.list);
router.get('/:id', controller.details);

export default router;