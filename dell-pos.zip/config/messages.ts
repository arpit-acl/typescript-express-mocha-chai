interface messageFormat {
  [key: string]: {
    [key: string]: string
  };
}
export default <messageFormat>{
  en: {

  },
}