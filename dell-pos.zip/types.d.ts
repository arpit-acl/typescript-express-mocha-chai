declare namespace Express {
    export interface Request {
        _user: any;
    }
    export interface Response {
        _user: any;
    }
  }